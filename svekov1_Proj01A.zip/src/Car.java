/**
 * Represents a car entity with attributes for make, year, and price. Each car object can be
 * compared to another based on the make and year, which allows them to be sorted in an ordered list.
 * This class encapsulates the primary characteristics of a car and provides necessary functionalities
 * to access and compare its properties.
 *
 * CSC 1351 Programming Project No 1
 * Section 2
 *
 * @author Samuel Vekovius
 * @since October 16, 2023
 *
 */
public class Car implements Comparable<Car> {
    // Attributes to store make, year, and price of the car
    private String make;
    private int year;
    private int price;
    /**
     * Constructor to initialize a Car with make, year, and price.
     */
    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
    }
    // Getter methods for the attributes
    public String getMake() {
        return make;
    }

    public int getYear() {
        return year;
    }

    public int getPrice() {
        return price;
    }
    /**
     * Method to compare this car to another car based on make and year.
     * If the makes are the same, cars are compared by year.
     */
    @Override
    public int compareTo(Car other) {
        if (this.make.compareTo(other.make) < 0) {
            return -1;
        } else if (this.make.compareTo(other.make) > 0) {
            return 1;
        } else {
            return Integer.compare(this.year, other.year);
        }
    }
    /**
     * Converts the Car object to a string representation.
     */
    @Override
    public String toString() {
        return String.format("Make: %-12s\nYear: %-10d\nPrice: $%,d\n", make, year, price);
    }
}