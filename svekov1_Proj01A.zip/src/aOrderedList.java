/**
 * Manages an ordered list of generic items that implement the Comparable interface. The list is dynamically resizable
 * and supports operations like adding, removing, and retrieving elements. The ordering is maintained based on the
 * natural order of the elements, as determined by their compareTo method. This class also provides an iterator
 * mechanism to traverse through the list in a sequential manner.
 *
 * CSC 1351 Programming Project No 1
 * Section 2
 *
 * @author Samuel Vekovius
 * @since October 16, 2023
 *
 */
import java.util.Arrays;

public class aOrderedList<T extends Comparable<T>> {
    // Attributes to store the list, its current size, number of elements, and iterator position
    private static final int SIZEINCREMENTS = 20;
    private T[] oList;
    private int listSize;
    private int numObjects;
    private int curr;  // For iterator

    @SuppressWarnings("unchecked")

    /**
     * Default constructor. Initializes an empty list with a default size.
     */
    public aOrderedList() {
        this.oList = (T[]) new Comparable[SIZEINCREMENTS];
        this.listSize = SIZEINCREMENTS;
        this.numObjects = 0;
        this.curr = 0;
    }

    /**
     * Adds a new object to the ordered list at the correct position.
     * Resizes the list if necessary.
     */
    public void add(T newObj) {
        if (numObjects == listSize) {
            listSize *= 2;
            oList = Arrays.copyOf(oList, listSize);
        }

        int position = 0;
        while (position < numObjects && oList[position].compareTo(newObj) <= 0) {
            position++;
        }

        for (int i = numObjects; i > position; i--) {
            oList[i] = oList[i - 1];
        }

        oList[position] = newObj;
        numObjects++;
    }

    /**
     * Retrieves an object from the list by index.
     */
    public T get(int index) {
        if (index >= 0 && index < numObjects) {
            return oList[index];
        } else {
            throw new IndexOutOfBoundsException("Index out of range.");
        }
    }

    /**
     * Removes an object from the list by index.
     */
    public void remove(int index) {
        if (index >= 0 && index < numObjects) {
            for (int i = index; i < numObjects - 1; i++) {
                oList[i] = oList[i + 1];
            }
            numObjects--;
            oList[numObjects] = null;
        } else {
            throw new IndexOutOfBoundsException("Index out of range.");
        }
    }
    public int size() {
        return numObjects;
    }

    /**
     * Resets the iterator position to the beginning of the list.
     */
    public void reset() {
        curr = 0;
    }

    /**
     * Returns the next object in the list and advances the iterator.
     */
    public T next() {
        if (curr < numObjects) {
            return oList[curr++];
        } else {
            throw new IndexOutOfBoundsException("No more elements to iterate.");
        }
    }

    /**
     * Checks if there are more objects to iterate through in the list.
     */
    public boolean hasNext() {
        return curr < numObjects;
    }

    /**
     * Returns a string representation of the ordered list.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Number of cars: %-5d\n\n", numObjects));
        for (int i = 0; i < numObjects; i++) {
            T obj = oList[i];
            sb.append(obj.toString()).append("\n");
            if (i < numObjects - 1) {
                sb.append("\n");  // Adds an extra newline between cars
            }
        }
        return sb.toString();
    }
}