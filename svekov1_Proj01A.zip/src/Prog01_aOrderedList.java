/**
 * This class reads car data from an input file, populates an ordered list of Car objects,
 * and then displays the ordered list to the console. The user is prompted to enter the
 * input filename, and the program handles file not found errors. The primary
 * purpose is to showcase the use and functionality of ordered lists in a real-world context.
 *
 * CSC 1351 Programming Project No <enter project number here>
 * Section 2
 *
 * @author Samuel Vekovius
 * @since October 23, 2023
 *
 */
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Prog01_aOrderedList {
    // Initialize an ordered list to store Car objects
    public static void main(String[] args) {
        aOrderedList<Car> carList = new aOrderedList<>();

        Scanner scanner = null;
        try {
    // Prompt user for input file and read it
            scanner = getInputFile("Enter input filename: ");
    // Process each line in the file
            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                switch (data[0]) {
                    case "A":
    // Check if the line action is 'A' (for 'Add')
                        Car car = new Car(data[1], Integer.parseInt(data[2]), Integer.parseInt(data[3]));
    // Create a Car object from the data and add it to the ordered list
                        carList.add(car);
                        break;
                    case "D":
    // Check if the line action is 'D' (for 'Delete')                    // Assuming delete by car details for simplicity
                        Car deleteCar = new Car(data[1], Integer.parseInt(data[2]), 0);
                        for (int i = 0; i < carList.size(); i++) {
                            if (carList.get(i).equals(deleteCar)) {
                                carList.remove(i);
                                break;
                            }
                        }
                        break;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found. Exiting program.");
        } finally {
            if (scanner != null) {
                scanner.close();
            }
        }
    // Display the ordered list of cars
        System.out.println(carList.toString());
    }

    /**
     * A utility method to prompt the user for a filename and return a Scanner for that file.
     * Continuously prompts the user until a valid file is provided or the user decides to exit.
     */
    public static Scanner getInputFile(String userPrompt) throws FileNotFoundException {
        Scanner console = new Scanner(System.in);
        System.out.print(userPrompt);
        String filename = console.nextLine();

        File file = new File(filename);
        if (!file.exists()) {
            System.out.println("File specified <" + filename + "> does not exist.");
            throw new FileNotFoundException("Specified file not found.");
        }
        return new Scanner(file);
    }
}
